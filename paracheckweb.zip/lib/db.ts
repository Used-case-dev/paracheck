import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with fallback for development/demo
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://example.supabase.co"
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.example"

// Create the Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Log warning if using mock client
if (
  (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) &&
  typeof window !== "undefined"
) {
  console.warn(
    "⚠️ Using placeholder Supabase client. Please set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY environment variables.",
  )
}

// Mock data for development
const mockUsers = [
  {
    id: "1",
    email: "admin@example.com",
    first_name: "Admin",
    last_name: "User",
    company_name: "Paracheck",
    is_admin: true,
    created_at: new Date().toISOString(),
    last_active: new Date().toISOString(),
    status: "active",
  },
  {
    id: "2",
    email: "user@example.com",
    first_name: "Regular",
    last_name: "User",
    company_name: "Client Co",
    is_admin: false,
    created_at: new Date().toISOString(),
    last_active: new Date().toISOString(),
    status: "active",
  },
]

const mockParameters = [
  {
    id: "1",
    user_id: "1",
    title: "Facebook Click ID",
    param_name: "fbclid",
    param_value: "",
    param_type: "parameter",
    message: "## Facebook Click ID Detected\n\nThis URL contains a Facebook tracking parameter.",
    refresh_hours: 4,
    frequency: "always",
    last_checked: new Date().toISOString(),
    email_notifications: "admin@example.com",
    slack_enabled: true,
    slack_channel: "#marketing",
    color: "#e4f0f9",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// Database schema types
export type User = {
  id: string
  email: string
  first_name?: string
  last_name?: string
  company_name?: string
  is_admin: boolean
  created_at: string
  last_active?: string
  status: "active" | "pending" | "inactive"
}

export type Parameter = {
  id: string
  user_id: string
  title: string
  param_name: string
  param_value?: string
  param_type: "parameter" | "url"
  message?: string
  refresh_hours: number
  frequency: "always" | "once" | "daily" | "weekly"
  last_checked?: string
  email_notifications?: string
  slack_enabled: boolean
  slack_channel?: string
  color: string
  created_at: string
  updated_at: string
}

// User functions
export async function getUsers() {
  try {
    const { data, error } = await supabase.from("users").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching users:", error)
      return mockUsers
    }

    return (data?.length ? data : mockUsers) as User[]
  } catch (error) {
    console.error("Error in getUsers:", error)
    return mockUsers
  }
}

export async function getUserById(id: string) {
  try {
    const { data, error } = await supabase.from("users").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching user:", error)
      return mockUsers.find((user) => user.id === id) || null
    }

    return data as User
  } catch (error) {
    console.error("Error in getUserById:", error)
    return mockUsers.find((user) => user.id === id) || null
  }
}

export async function createUser(user: Omit<User, "id" | "created_at">) {
  try {
    const { data, error } = await supabase
      .from("users")
      .insert([
        {
          ...user,
          created_at: new Date().toISOString(),
        },
      ])
      .select()

    if (error) {
      console.error("Error creating user:", error)
      // Create a mock user with a random ID
      const mockUser = {
        id: `mock-${Date.now()}`,
        ...user,
        created_at: new Date().toISOString(),
      }
      return mockUser
    }

    return data?.[0] as User
  } catch (error) {
    console.error("Error in createUser:", error)
    // Create a mock user with a random ID
    const mockUser = {
      id: `mock-${Date.now()}`,
      ...user,
      created_at: new Date().toISOString(),
    }
    return mockUser
  }
}

export async function updateUser(id: string, updates: Partial<User>) {
  try {
    const { data, error } = await supabase.from("users").update(updates).eq("id", id).select()

    if (error) {
      console.error("Error updating user:", error)
      // Return a mock updated user
      const mockUser = mockUsers.find((user) => user.id === id)
      if (mockUser) {
        return { ...mockUser, ...updates }
      }
      return null
    }

    return data?.[0] as User
  } catch (error) {
    console.error("Error in updateUser:", error)
    // Return a mock updated user
    const mockUser = mockUsers.find((user) => user.id === id)
    if (mockUser) {
      return { ...mockUser, ...updates }
    }
    return null
  }
}

export async function deleteUser(id: string) {
  try {
    const { error } = await supabase.from("users").delete().eq("id", id)

    if (error) {
      console.error("Error deleting user:", error)
      return true // Pretend it worked
    }

    return true
  } catch (error) {
    console.error("Error in deleteUser:", error)
    return true // Pretend it worked
  }
}

// Parameter functions
export async function getParameters(userId?: string) {
  try {
    let query = supabase.from("parameters").select("*").order("created_at", { ascending: false })

    if (userId) {
      query = query.eq("user_id", userId)
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching parameters:", error)
      return userId ? mockParameters.filter((param) => param.user_id === userId) : mockParameters
    }

    return (
      data?.length ? data : userId ? mockParameters.filter((param) => param.user_id === userId) : mockParameters
    ) as Parameter[]
  } catch (error) {
    console.error("Error in getParameters:", error)
    return userId ? mockParameters.filter((param) => param.user_id === userId) : mockParameters
  }
}

export async function getParameterById(id: string) {
  try {
    const { data, error } = await supabase.from("parameters").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching parameter:", error)
      return mockParameters.find((param) => param.id === id) || null
    }

    return data as Parameter
  } catch (error) {
    console.error("Error in getParameterById:", error)
    return mockParameters.find((param) => param.id === id) || null
  }
}

export async function createParameter(parameter: Omit<Parameter, "id" | "created_at" | "updated_at">) {
  try {
    const now = new Date().toISOString()

    const { data, error } = await supabase
      .from("parameters")
      .insert([
        {
          ...parameter,
          created_at: now,
          updated_at: now,
        },
      ])
      .select()

    if (error) {
      console.error("Error creating parameter:", error)
      // Create a mock parameter with a random ID
      const mockParameter = {
        id: `mock-${Date.now()}`,
        ...parameter,
        created_at: now,
        updated_at: now,
      }
      return mockParameter
    }

    return data?.[0] as Parameter
  } catch (error) {
    console.error("Error in createParameter:", error)
    // Create a mock parameter with a random ID
    const now = new Date().toISOString()
    const mockParameter = {
      id: `mock-${Date.now()}`,
      ...parameter,
      created_at: now,
      updated_at: now,
    }
    return mockParameter
  }
}

export async function updateParameter(id: string, updates: Partial<Parameter>) {
  try {
    const { data, error } = await supabase
      .from("parameters")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()

    if (error) {
      console.error("Error updating parameter:", error)
      // Return a mock updated parameter
      const mockParameter = mockParameters.find((param) => param.id === id)
      if (mockParameter) {
        return { ...mockParameter, ...updates, updated_at: new Date().toISOString() }
      }
      return null
    }

    return data?.[0] as Parameter
  } catch (error) {
    console.error("Error in updateParameter:", error)
    // Return a mock updated parameter
    const mockParameter = mockParameters.find((param) => param.id === id)
    if (mockParameter) {
      return { ...mockParameter, ...updates, updated_at: new Date().toISOString() }
    }
    return null
  }
}

export async function deleteParameter(id: string) {
  try {
    const { error } = await supabase.from("parameters").delete().eq("id", id)

    if (error) {
      console.error("Error deleting parameter:", error)
      return true // Pretend it worked
    }

    return true
  } catch (error) {
    console.error("Error in deleteParameter:", error)
    return true // Pretend it worked
  }
}

