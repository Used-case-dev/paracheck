"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function LandingPage() {
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("paracheck-user")
    if (userData) {
      // If logged in, redirect to dashboard
      router.push("/dashboard")
    }
  }, [router])

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Image src="/logo.png" alt="Paracheck Logo" width={34} height={34} className="rounded-md" />
            <div className="flex flex-col">
              <span className="font-bold text-lg">paracheck</span>
              <span className="text-xs text-gray-500">parameter pop up</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline">Log in</Button>
            </Link>
            <Link href="/login">
              <Button>Sign up</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section - Verbeterd met een moderne gradient en betere layout */}
      <section className="bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-600 py-20 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">Track URL Parameters met Gemak</h1>
            <p className="text-xl text-blue-100 mb-10 leading-relaxed">
              Paracheck helpt je bij het monitoren en analyseren van URL-parameters op al je websites. Ontvang meldingen
              wanneer specifieke parameters verschijnen en onderneem actie.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/login">
                <Button size="lg" className="px-8 bg-white text-blue-600 hover:bg-blue-50">
                  Aan de slag
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="px-8 border-white text-white hover:bg-blue-700">
                Demo bekijken
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Verbeterd met betere kaarten en iconen */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Belangrijkste Functies</h2>
          <p className="text-xl text-gray-600 text-center mb-16 max-w-3xl mx-auto">
            Ontdek hoe Paracheck je helpt om je website-parameters effectief te beheren
          </p>
          <div className="grid md:grid-cols-3 gap-10">
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-7 w-7 text-blue-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Parameter Tracking</h3>
              <p className="text-gray-600 leading-relaxed">
                Volg specifieke URL-parameters zoals UTM-tags, verwijzings-ID's en aangepaste parameters op al je
                websites.
              </p>
            </div>
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-7 w-7 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Slimme Notificaties</h3>
              <p className="text-gray-600 leading-relaxed">
                Ontvang meldingen via e-mail of Slack wanneer specifieke parameters worden gedetecteerd op je website.
              </p>
            </div>
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-purple-100 rounded-full flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-7 w-7 text-purple-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Analytics Dashboard</h3>
              <p className="text-gray-600 leading-relaxed">
                Bekijk gedetailleerde analyses over parametergebruik, frequentie en patronen op al je websites.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section - Nieuw toegevoegd voor professionaliteit */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Wat onze klanten zeggen</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-blue-600 font-bold">JD</span>
                </div>
                <div>
                  <h4 className="font-semibold">Jan Derksen</h4>
                  <p className="text-sm text-gray-500">Marketing Manager, TechCorp</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Paracheck heeft onze marketingcampagnes getransformeerd. We kunnen nu precies zien welke parameters het
                beste presteren en onze strategie daarop aanpassen."
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-green-600 font-bold">LV</span>
                </div>
                <div>
                  <h4 className="font-semibold">Lisa Verhoeven</h4>
                  <p className="text-sm text-gray-500">Product Owner, E-commerce Plus</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "De integratie met Slack heeft ons team veel tijd bespaard. We krijgen direct meldingen wanneer
                belangrijke parameters worden gedetecteerd."
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-purple-600 font-bold">MK</span>
                </div>
                <div>
                  <h4 className="font-semibold">Mark Kuijpers</h4>
                  <p className="text-sm text-gray-500">Developer, WebSolutions</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Als ontwikkelaar waardeer ik de flexibiliteit en betrouwbaarheid van Paracheck. De API is goed
                gedocumenteerd en eenvoudig te integreren."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Verbeterd met betere achtergrond en layout */}
      <section className="py-20 bg-gradient-to-br from-indigo-600 to-blue-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Klaar om te beginnen?</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
            Sluit je aan bij duizenden marketeers en ontwikkelaars die Paracheck gebruiken om hun URL-parameters te
            monitoren.
          </p>
          <Link href="/login">
            <Button size="lg" className="px-10 py-6 text-lg bg-white text-blue-600 hover:bg-blue-50">
              Gratis aanmelden
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer - Verbeterd met betere layout en styling */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-10 md:mb-0 md:w-1/3">
              <div className="flex items-center gap-2 mb-6">
                <Image src="/logo.png" alt="Paracheck Logo" width={40} height={40} className="rounded-md" />
                <div className="flex flex-col">
                  <span className="font-bold text-xl">paracheck</span>
                  <span className="text-xs text-gray-400">parameter pop up</span>
                </div>
              </div>
              <p className="text-gray-400 max-w-xs leading-relaxed">
                De eenvoudigste manier om URL-parameters te volgen en te monitoren op al je websites.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-10 md:w-2/3">
              <div>
                <h3 className="font-semibold text-lg mb-4">Product</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Functies
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Prijzen
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Integraties
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Updates
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Resources</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Documentatie
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      API Referentie
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Blog
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Support
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Bedrijf</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Over ons
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Carrières
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Privacy
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Voorwaarden
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-16 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Paracheck. Alle rechten voorbehouden.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

