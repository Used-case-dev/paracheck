"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SettingsPage() {
  const [generalSettings, setGeneralSettings] = useState({
    companyName: "Paracheck",
    websiteUrl: "https://paracheck.app",
    timezone: "UTC",
    dateFormat: "MM/DD/YYYY",
  })

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    slackNotifications: true,
    slackWebhookUrl: "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",
    defaultEmailRecipients: "admin@example.com",
    defaultSlackChannel: "#paracheck",
  })

  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: "light",
    primaryColor: "#000000",
    logoUrl: "/logo.png",
    customCss: "",
  })

  const [apiSettings, setApiSettings] = useState({
    apiKey: "pk_test_51HZ5Z5J2Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5Z5Z5J2Z5",
    webhookUrl: "",
    enableWebhooks: false,
  })

  const handleSaveGeneral = () => {
    alert("General settings saved!")
  }

  const handleSaveNotifications = () => {
    alert("Notification settings saved!")
  }

  const handleSaveAppearance = () => {
    alert("Appearance settings saved!")
  }

  const handleSaveApi = () => {
    alert("API settings saved!")
  }

  const handleResetApiKey = () => {
    if (confirm("Are you sure you want to reset your API key? This action cannot be undone.")) {
      setApiSettings({
        ...apiSettings,
        apiKey: "pk_test_" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
      })
    }
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Manage your basic account settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="companyName">Company Name</Label>
                <Input
                  id="companyName"
                  value={generalSettings.companyName}
                  onChange={(e) => setGeneralSettings({ ...generalSettings, companyName: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="websiteUrl">Website URL</Label>
                <Input
                  id="websiteUrl"
                  type="url"
                  value={generalSettings.websiteUrl}
                  onChange={(e) => setGeneralSettings({ ...generalSettings, websiteUrl: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="timezone">Timezone</Label>
                <Select
                  value={generalSettings.timezone}
                  onValueChange={(value) => setGeneralSettings({ ...generalSettings, timezone: value })}
                >
                  <SelectTrigger id="timezone">
                    <SelectValue placeholder="Select timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC">UTC</SelectItem>
                    <SelectItem value="America/New_York">Eastern Time (ET)</SelectItem>
                    <SelectItem value="America/Chicago">Central Time (CT)</SelectItem>
                    <SelectItem value="America/Denver">Mountain Time (MT)</SelectItem>
                    <SelectItem value="America/Los_Angeles">Pacific Time (PT)</SelectItem>
                    <SelectItem value="Europe/London">London</SelectItem>
                    <SelectItem value="Europe/Paris">Paris</SelectItem>
                    <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateFormat">Date Format</Label>
                <Select
                  value={generalSettings.dateFormat}
                  onValueChange={(value) => setGeneralSettings({ ...generalSettings, dateFormat: value })}
                >
                  <SelectTrigger id="dateFormat">
                    <SelectValue placeholder="Select date format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                    <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                    <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveGeneral}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailNotifications">Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={notificationSettings.emailNotifications}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, emailNotifications: checked })
                  }
                />
              </div>

              {notificationSettings.emailNotifications && (
                <div className="space-y-2">
                  <Label htmlFor="defaultEmailRecipients">Default Email Recipients</Label>
                  <Input
                    id="defaultEmailRecipients"
                    placeholder="email1@example.com, email2@example.com"
                    value={notificationSettings.defaultEmailRecipients}
                    onChange={(e) =>
                      setNotificationSettings({ ...notificationSettings, defaultEmailRecipients: e.target.value })
                    }
                  />
                  <p className="text-xs text-muted-foreground">Comma-separated list of email addresses</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="slackNotifications">Slack Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive notifications via Slack</p>
                </div>
                <Switch
                  id="slackNotifications"
                  checked={notificationSettings.slackNotifications}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, slackNotifications: checked })
                  }
                />
              </div>

              {notificationSettings.slackNotifications && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="slackWebhookUrl">Slack Webhook URL</Label>
                    <Input
                      id="slackWebhookUrl"
                      type="url"
                      value={notificationSettings.slackWebhookUrl}
                      onChange={(e) =>
                        setNotificationSettings({ ...notificationSettings, slackWebhookUrl: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="defaultSlackChannel">Default Slack Channel</Label>
                    <Input
                      id="defaultSlackChannel"
                      placeholder="#general"
                      value={notificationSettings.defaultSlackChannel}
                      onChange={(e) =>
                        setNotificationSettings({ ...notificationSettings, defaultSlackChannel: e.target.value })
                      }
                    />
                  </div>
                </>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveNotifications}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>Customize the look and feel of your dashboard</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="theme">Theme</Label>
                <Select
                  value={appearanceSettings.theme}
                  onValueChange={(value) => setAppearanceSettings({ ...appearanceSettings, theme: value })}
                >
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Select theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="primaryColor">Primary Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="primaryColor"
                    type="color"
                    className="w-12 h-10 p-1"
                    value={appearanceSettings.primaryColor}
                    onChange={(e) => setAppearanceSettings({ ...appearanceSettings, primaryColor: e.target.value })}
                  />
                  <Input
                    type="text"
                    value={appearanceSettings.primaryColor}
                    onChange={(e) => setAppearanceSettings({ ...appearanceSettings, primaryColor: e.target.value })}
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="logoUrl">Logo URL</Label>
                <Input
                  id="logoUrl"
                  type="url"
                  value={appearanceSettings.logoUrl}
                  onChange={(e) => setAppearanceSettings({ ...appearanceSettings, logoUrl: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="customCss">Custom CSS</Label>
                <Textarea
                  id="customCss"
                  placeholder=".my-class { color: blue; }"
                  className="font-mono"
                  value={appearanceSettings.customCss}
                  onChange={(e) => setAppearanceSettings({ ...appearanceSettings, customCss: e.target.value })}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveAppearance}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>API Settings</CardTitle>
              <CardDescription>Manage your API keys and webhooks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="apiKey">API Key</Label>
                <div className="flex gap-2">
                  <Input id="apiKey" value={apiSettings.apiKey} readOnly className="font-mono flex-1" />
                  <Button variant="outline" onClick={handleResetApiKey}>
                    Reset
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Your API key is used to authenticate API requests. Keep it secret!
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="enableWebhooks">Enable Webhooks</Label>
                  <p className="text-sm text-muted-foreground">
                    Send webhook notifications when parameters are detected
                  </p>
                </div>
                <Switch
                  id="enableWebhooks"
                  checked={apiSettings.enableWebhooks}
                  onCheckedChange={(checked) => setApiSettings({ ...apiSettings, enableWebhooks: checked })}
                />
              </div>

              {apiSettings.enableWebhooks && (
                <div className="space-y-2">
                  <Label htmlFor="webhookUrl">Webhook URL</Label>
                  <Input
                    id="webhookUrl"
                    type="url"
                    placeholder="https://example.com/webhook"
                    value={apiSettings.webhookUrl}
                    onChange={(e) => setApiSettings({ ...apiSettings, webhookUrl: e.target.value })}
                  />
                  <p className="text-xs text-muted-foreground">
                    We'll send a POST request to this URL when parameters are detected
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveApi}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

