"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { getParameters } from "@/lib/db"

export default function DashboardPage() {
  const [parameters, setParameters] = useState([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    urlBased: 0,
    paramBased: 0,
  })

  useEffect(() => {
    async function loadData() {
      try {
        // Try to fetch from Supabase
        const userData = localStorage.getItem("paracheck-user")
        if (!userData) return

        const user = JSON.parse(userData)

        // Check if it's a demo user (non-UUID id)
        const isDemo =
          user.id === "demo-user" || !user.id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)

        let params = []

        if (!isDemo) {
          // Only fetch from Supabase if it's a real user with UUID
          params = await getParameters(user.id)
        }

        // If we get data from Supabase, use it
        if (params && params.length > 0) {
          setParameters(params)

          // Calculate stats
          setStats({
            total: params.length,
            active: params.filter((p) => p.last_checked).length,
            urlBased: params.filter((p) => p.param_type === "url").length,
            paramBased: params.filter((p) => p.param_type === "parameter").length,
          })
        } else {
          // Otherwise use mock data from parameters page
          const mockParams = [
            {
              id: 1,
              title: "Facebook Click ID",
              paramName: "fbclid",
              paramValue: "",
              paramType: "parameter",
              message:
                "## Facebook Click ID Detected\n\nThis URL contains a Facebook tracking parameter.\n\n[ ] Check referral source\n[ ] Verify campaign settings\n[x] Document in analytics",
              refreshHours: 4,
              frequency: "always",
              lastChecked: Date.now() - 3600000, // 1 hour ago
              emailNotifications: "admin@example.com",
              slackEnabled: true,
              slackChannel: "#marketing",
              color: "#e4f0f9", // Light blue-white
            },
            {
              id: 2,
              title: "Google Analytics",
              paramName: "utm_source",
              paramValue: "newsletter",
              paramType: "parameter",
              message:
                "## Newsletter Traffic\n\nThis visitor came from our newsletter campaign.\n\n[ ] Check conversion rate\n[ ] Update campaign dashboard",
              refreshHours: 24,
              frequency: "daily",
              lastChecked: Date.now() - 86400000, // 1 day ago
              emailNotifications: "",
              slackEnabled: false,
              slackChannel: "",
              color: "#f9f3e4", // Light warm beige
            },
            {
              id: 3,
              title: "Product Page",
              paramName: "https://example.com/products/",
              paramValue: "",
              paramType: "url",
              message:
                "## Product Page Visit\n\n[ ] Check if user added to cart\n[ ] Monitor time spent on page\n[ ] Track clicks on related products",
              refreshHours: 2,
              frequency: "always",
              lastChecked: null,
              emailNotifications: "sales@example.com",
              slackEnabled: true,
              slackChannel: "#sales",
              color: "#f1e4f9", // Light lavender
            },
          ]

          setParameters(mockParams)

          // Calculate stats
          setStats({
            total: mockParams.length,
            active: mockParams.filter((p) => p.lastChecked).length,
            urlBased: mockParams.filter((p) => p.paramType === "url").length,
            paramBased: mockParams.filter((p) => p.paramType === "parameter").length,
          })
        }
      } catch (error) {
        console.error("Error loading parameters:", error)

        // If there's an error, fall back to mock data
        const mockParams = [
          {
            id: 1,
            title: "Facebook Click ID",
            paramName: "fbclid",
            paramValue: "",
            paramType: "parameter",
            message:
              "## Facebook Click ID Detected\n\nThis URL contains a Facebook tracking parameter.\n\n[ ] Check referral source\n[ ] Verify campaign settings\n[x] Document in analytics",
            refreshHours: 4,
            frequency: "always",
            lastChecked: Date.now() - 3600000, // 1 hour ago
            emailNotifications: "admin@example.com",
            slackEnabled: true,
            slackChannel: "#marketing",
            color: "#e4f0f9", // Light blue-white
          },
          {
            id: 2,
            title: "Google Analytics",
            paramName: "utm_source",
            paramValue: "newsletter",
            paramType: "parameter",
            message:
              "## Newsletter Traffic\n\nThis visitor came from our newsletter campaign.\n\n[ ] Check conversion rate\n[ ] Update campaign dashboard",
            refreshHours: 24,
            frequency: "daily",
            lastChecked: Date.now() - 86400000, // 1 day ago
            emailNotifications: "",
            slackEnabled: false,
            slackChannel: "",
            color: "#f9f3e4", // Light warm beige
          },
          {
            id: 3,
            title: "Product Page",
            paramName: "https://example.com/products/",
            paramValue: "",
            paramType: "url",
            message:
              "## Product Page Visit\n\n[ ] Check if user added to cart\n[ ] Monitor time spent on page\n[ ] Track clicks on related products",
            refreshHours: 2,
            frequency: "always",
            lastChecked: null,
            emailNotifications: "sales@example.com",
            slackEnabled: true,
            slackChannel: "#sales",
            color: "#f1e4f9", // Light lavender
          },
        ]

        setParameters(mockParams)

        // Calculate stats
        setStats({
          total: mockParams.length,
          active: mockParams.filter((p) => p.lastChecked).length,
          urlBased: mockParams.filter((p) => p.paramType === "url").length,
          paramBased: mockParams.filter((p) => p.paramType === "parameter").length,
        })
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  // Sample data for the chart
  const chartData = [
    { name: "Mon", views: 120, notifications: 15 },
    { name: "Tue", views: 160, notifications: 20 },
    { name: "Wed", views: 180, notifications: 25 },
    { name: "Thu", views: 190, notifications: 30 },
    { name: "Fri", views: 170, notifications: 20 },
    { name: "Sat", views: 120, notifications: 15 },
    { name: "Sun", views: 100, notifications: 10 },
  ]

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">Total Parameters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-800">{stats.total}</div>
            <p className="text-xs text-blue-600">+2.5% from last month</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Active Parameters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-800">{stats.active}</div>
            <p className="text-xs text-green-600">
              {stats.total > 0 ? Math.round((stats.active / stats.total) * 100) : 0}% of total
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">URL Based</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-800">{stats.urlBased}</div>
            <p className="text-xs text-purple-600">
              {stats.total > 0 ? Math.round((stats.urlBased / stats.total) * 100) : 0}% of total
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-700">Parameter Based</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-800">{stats.paramBased}</div>
            <p className="text-xs text-amber-600">
              {stats.total > 0 ? Math.round((stats.paramBased / stats.total) * 100) : 0}% of total
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Activity Overview</CardTitle>
            <CardDescription>Page views and notifications for the last 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ChartContainer
                config={{
                  views: {
                    label: "Page Views",
                    color: "hsl(210, 100%, 50%)",
                  },
                  notifications: {
                    label: "Notifications",
                    color: "hsl(130, 60%, 50%)",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="views" fill="var(--color-views)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="notifications" fill="var(--color-notifications)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

