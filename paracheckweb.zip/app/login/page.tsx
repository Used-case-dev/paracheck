"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // For demo purposes, we'll use a simple login
      // In a real app, you would use Supabase auth

      // Create a demo user
      const demoUser = {
        id: "demo-user",
        email: email,
        firstName: "Demo",
        lastName: "User",
        companyName: "Demo Company",
        isAdmin: true,
      }

      localStorage.setItem("paracheck-user", JSON.stringify(demoUser))
      router.push("/dashboard")
    } catch (error: any) {
      console.error("Login error:", error)
      setError("Failed to login. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <div className="flex items-center gap-2">
              <Image src="/logo.png" alt="Paracheck Logo" width={40} height={40} className="rounded-md" />
              <div className="flex flex-col">
                <span className="font-bold text-xl">paracheck</span>
                <span className="text-xs text-gray-500">parameter pop up</span>
              </div>
            </div>
          </div>
          <CardTitle className="text-2xl text-center">Welkom terug</CardTitle>
          <CardDescription className="text-center">Voer je e-mail in om in te loggen op je account</CardDescription>
        </CardHeader>
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="m@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Wachtwoord</Label>
                <a href="#" className="text-xs text-primary hover:underline">
                  Wachtwoord vergeten?
                </a>
              </div>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            {error && <p className="text-sm text-red-500">{error}</p>}
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Inloggen..." : "Inloggen"}
            </Button>
          </CardFooter>
        </form>
        <div className="px-8 pb-8 text-center text-sm text-muted-foreground">
          Nog geen account?{" "}
          <a href="#" className="text-primary hover:underline">
            Aanmelden
          </a>
        </div>
      </Card>
    </div>
  )
}

